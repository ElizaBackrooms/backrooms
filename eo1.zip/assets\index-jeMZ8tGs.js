var d=Object.defineProperty;var l=(r,t,s)=>t in r?d(r,t,{enumerable:!0,configurable:!0,writable:!0,value:s}):r[t]=s;var n=(r,t,s)=>l(r,typeof t!="symbol"?t+"":t,s);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))i(e);new MutationObserver(e=>{for(const a of e)if(a.type==="childList")for(const o of a.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function s(e){const a={};return e.integrity&&(a.integrity=e.integrity),e.referrerPolicy&&(a.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?a.credentials="include":e.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function i(e){if(e.ep)return;e.ep=!0;const a=s(e);fetch(e.href,a)}})();const c="https://infinite-backrooms.onrender.com";class h{constructor(){n(this,"conversation");n(this,"statusIndicator");n(this,"statusText");n(this,"viewerCount");n(this,"exchangeCount");n(this,"startBtn");n(this,"stopBtn");n(this,"resetBtn");n(this,"eventSource",null);n(this,"isRunning",!1);n(this,"displayedIds",new Set);n(this,"archivesList");n(this,"archiveViewer");n(this,"archiveConversation");n(this,"archiveTitle");n(this,"backToListBtn");this.conversation=document.getElementById("conversation"),this.statusIndicator=document.getElementById("status-indicator"),this.statusText=document.getElementById("status-text"),this.viewerCount=document.getElementById("viewer-count"),this.exchangeCount=document.getElementById("exchange-count"),this.startBtn=document.getElementById("start-btn"),this.stopBtn=document.getElementById("stop-btn"),this.resetBtn=document.getElementById("reset-btn"),this.archivesList=document.getElementById("archives-list"),this.archiveViewer=document.getElementById("archive-viewer"),this.archiveConversation=document.getElementById("archive-conversation"),this.archiveTitle=document.getElementById("archive-title"),this.backToListBtn=document.getElementById("back-to-list"),this.init()}async init(){await this.loadInitialState(),this.connectToStream(),this.setupControls(),this.setupTabs()}async loadInitialState(){try{const s=await(await fetch(`${c}/api/state`)).json();this.conversation.innerHTML="";for(const i of s.messages)this.displayMessage(i,!1,this.conversation),this.displayedIds.add(i.id);this.updateStatus(s.isRunning),this.exchangeCount.textContent=s.totalExchanges.toString(),this.viewerCount.textContent=s.viewers.toString(),this.scrollToBottom()}catch(t){console.error("Failed to load initial state:",t),this.conversation.innerHTML=`
        <div class="loading">
          <p>> ERROR: Failed to connect to the backrooms</p>
          <p>> The void is unreachable...</p>
        </div>
      `}}connectToStream(){this.eventSource=new EventSource(`${c}/api/stream`),this.eventSource.onopen=()=>{console.log("Connected to backrooms stream"),this.statusIndicator.className="status-indicator connecting"},this.eventSource.onmessage=t=>{const s=JSON.parse(t.data);this.handleStreamEvent(s)},this.eventSource.onerror=()=>{console.error("Stream connection error"),this.statusIndicator.className="status-indicator stopped",this.statusText.textContent="RECONNECTING...",setTimeout(async()=>{await this.loadInitialState(),this.connectToStream()},5e3)}}handleStreamEvent(t){switch(t.type){case"message":this.displayedIds.has(t.message.id)||(this.displayMessage(t.message,!0,this.conversation),this.displayedIds.add(t.message.id),this.exchangeCount.textContent=(parseInt(this.exchangeCount.textContent||"0")+1).toString());break;case"status":this.updateStatus(t.isRunning);break;case"viewers":this.viewerCount.textContent=t.count.toString();break;case"reset":this.conversation.innerHTML="",this.displayedIds.clear(),this.exchangeCount.textContent="0";break}}displayMessage(t,s,i){const e=document.createElement("div");e.className=`message ${t.entity}`,s||(e.style.animation="none");const a=new Date(t.timestamp).toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit"}),o=t.image?`<div class="message-image">
           <img src="${t.image}" alt="AI Generated Image" loading="lazy" />
           <span class="image-label">⌬ GENERATED VISUALIZATION</span>
         </div>`:"";e.innerHTML=`
      <div class="message-header">
        <span class="message-entity ${t.entity}">[${t.entity}]</span>
        <span class="message-time">${a}</span>
      </div>
      <div class="message-content">${this.escapeHtml(t.content)}</div>
      ${o}
    `,i.appendChild(e),s&&this.scrollToBottom()}escapeHtml(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}updateStatus(t){this.isRunning=t,t?(this.statusIndicator.className="status-indicator live",this.statusText.textContent="LIVE",this.startBtn.disabled=!0,this.stopBtn.disabled=!1):(this.statusIndicator.className="status-indicator stopped",this.statusText.textContent="STOPPED",this.startBtn.disabled=!1,this.stopBtn.disabled=!0)}async adminAction(t,s){const i=prompt(`Enter admin code to ${s}:`);if(!i)return!1;try{const e=await fetch(`${c}${t}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({adminCode:i})});if(!e.ok){const a=await e.json();return alert(a.error||"Action failed"),!1}return!0}catch(e){return console.error(`Failed to ${s}:`,e),alert(`Failed to ${s}`),!1}}setupControls(){this.startBtn.addEventListener("click",async()=>{this.startBtn.disabled=!0,await this.adminAction("/api/start","start conversation")||(this.startBtn.disabled=!1)}),this.stopBtn.addEventListener("click",async()=>{this.stopBtn.disabled=!0,await this.adminAction("/api/stop","stop conversation")||(this.stopBtn.disabled=!1)}),this.resetBtn.addEventListener("click",async()=>{confirm("Reset the conversation? This will clear all messages.")&&await this.adminAction("/api/reset","reset conversation")}),this.backToListBtn.addEventListener("click",()=>{this.archiveViewer.style.display="none",this.archivesList.style.display="block"})}setupTabs(){const t=document.querySelectorAll(".tab-btn"),s=document.querySelectorAll(".tab-content");t.forEach(i=>{i.addEventListener("click",()=>{var a;const e=i.getAttribute("data-tab");t.forEach(o=>o.classList.remove("active")),s.forEach(o=>o.classList.remove("active")),i.classList.add("active"),(a=document.getElementById(`${e}-tab`))==null||a.classList.add("active"),e==="archives"&&this.loadArchives()})})}async loadArchives(){this.archivesList.innerHTML=`
      <div class="loading">
        <p>> Fetching archives from the void...</p>
      </div>
    `;try{const s=await(await fetch(`${c}/api/archives`)).json();if(s.archives.length===0){this.archivesList.innerHTML=`
          <div class="empty-archives">
            <p>> No archives found yet.</p>
            <p>> Archives are saved hourly when the conversation is active.</p>
          </div>
        `;return}this.archivesList.innerHTML=s.archives.map(i=>{const e=new Date(i.timestamp),a=e.toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"}),o=e.toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit",hour12:!1});return`
          <div class="archive-item" data-filename="${i.filename}">
            <span class="archive-date">${a}</span>
            <span class="archive-time">${o}</span>
            <span class="archive-arrow">→</span>
          </div>
        `}).join(""),this.archivesList.querySelectorAll(".archive-item").forEach(i=>{i.addEventListener("click",()=>{const e=i.getAttribute("data-filename");e&&this.loadArchiveContent(e)})})}catch(t){console.error("Failed to load archives:",t),this.archivesList.innerHTML=`
        <div class="loading">
          <p>> ERROR: Failed to load archives</p>
          <p>> ${t}</p>
        </div>
      `}}async loadArchiveContent(t){this.archiveConversation.innerHTML=`
      <div class="loading">
        <p>> Loading archive ${t}...</p>
      </div>
    `,this.archivesList.style.display="none",this.archiveViewer.style.display="block",this.archiveTitle.textContent=t.replace(".json","");try{const i=await(await fetch(`${c}/api/archives/${t}`)).json();this.archiveConversation.innerHTML="";for(const e of i.messages)this.displayMessage(e,!1,this.archiveConversation)}catch(s){console.error("Failed to load archive content:",s),this.archiveConversation.innerHTML=`
        <div class="loading">
          <p>> ERROR: Failed to load archive</p>
        </div>
      `}}scrollToBottom(){this.conversation.scrollTop=this.conversation.scrollHeight}}document.addEventListener("DOMContentLoaded",()=>{new h});
