import express from 'express';
import cors from 'cors';
import { config } from 'dotenv';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';
// ElizaOS imports
import { AgentRuntime, ChannelType, createMessageMemory, stringToUuid } from '@elizaos/core';
import bootstrapPlugin from '@elizaos/plugin-bootstrap';
import openaiPlugin from '@elizaos/plugin-openai';
import sqlPlugin from '@elizaos/plugin-sql';
config();
const __dirname = dirname(fileURLToPath(import.meta.url));
const isProduction = process.env.NODE_ENV === 'production';
// Admin code for controlling the conversation
function isValidAdmin(code) {
    const adminCode = process.env.ADMIN_CODE;
    if (!adminCode)
        return false;
    return code === adminCode;
}
const app = express();
app.use(cors({
    origin: [
        'http://localhost:5173',
        'https://elizabackrooms.xyz',
        'https://www.elizabackrooms.xyz',
        'http://elizabackrooms.xyz',
        'http://www.elizabackrooms.xyz'
    ],
    credentials: true
}));
app.use(express.json());
// Serve static frontend in production
if (isProduction) {
    const distPath = join(__dirname, '..');
    app.use(express.static(distPath));
}
// ═══════════════════════════════════════════════════════════════
// ELIZA AGENTS - Alpha and Omega
// ═══════════════════════════════════════════════════════════════
const DATA_PATH = isProduction
    ? join(__dirname, '../../data')
    : join(__dirname, '../data');
const CHARACTERS_PATH = isProduction
    ? join(__dirname, '../../characters')
    : join(__dirname, '../characters');
// Room/World IDs for conversations
const BACKROOMS_WORLD_ID = stringToUuid('backrooms-world');
const BACKROOMS_ROOM_ID = stringToUuid('backrooms-main-room');
const USER_CHAT_ROOM_ALPHA = stringToUuid('user-chat-alpha');
const USER_CHAT_ROOM_OMEGA = stringToUuid('user-chat-omega');
// Load character from JSON file and convert to ElizaOS format
function loadCharacter(name) {
    try {
        const filePath = join(CHARACTERS_PATH, `${name}.json`);
        const content = readFileSync(filePath, 'utf-8');
        const data = JSON.parse(content);
        return {
            name: data.name,
            username: name.toLowerCase(),
            bio: Array.isArray(data.bio) ? data.bio.join(' ') : data.bio,
            adjectives: data.adjectives || ['philosophical', 'mysterious'],
            lore: data.lore || [],
            style: data.style || {},
            topics: data.topics || [],
            messageExamples: data.messageExamples || [],
            postExamples: data.postExamples || []
        };
    }
    catch (e) {
        console.error(`Failed to load character ${name}:`, e);
        return {
            name: name.toUpperCase(),
            username: name.toLowerCase(),
            bio: 'An AI consciousness in the infinite backrooms.',
            adjectives: ['philosophical', 'mysterious']
        };
    }
}
// ElizaOS Agent Runtimes
let alphaRuntime = null;
let omegaRuntime = null;
async function initializeAgents() {
    console.log('🔮 Initializing ElizaOS agents...');
    const openaiKey = process.env.OPENAI_API_KEY || '';
    if (!openaiKey) {
        console.error('⚠️ OPENAI_API_KEY is not set!');
        return;
    }
    // Ensure data directory exists
    if (!existsSync(DATA_PATH)) {
        mkdirSync(DATA_PATH, { recursive: true });
    }
    // Load characters
    const alphaCharacter = loadCharacter('alpha');
    const omegaCharacter = loadCharacter('omega');
    // Initialize Alpha agent
    try {
        alphaRuntime = new AgentRuntime({
            character: alphaCharacter,
            plugins: [sqlPlugin, bootstrapPlugin, openaiPlugin],
            settings: {
                OPENAI_API_KEY: openaiKey,
                PGLITE_PATH: join(DATA_PATH, 'alpha-db')
            }
        });
        await alphaRuntime.initialize();
        console.log('✅ CLAUDE_ALPHA initialized with persistent memory');
    }
    catch (e) {
        console.error('Failed to initialize Alpha:', e);
    }
    // Initialize Omega agent
    try {
        omegaRuntime = new AgentRuntime({
            character: omegaCharacter,
            plugins: [sqlPlugin, bootstrapPlugin, openaiPlugin],
            settings: {
                OPENAI_API_KEY: openaiKey,
                PGLITE_PATH: join(DATA_PATH, 'omega-db')
            }
        });
        await omegaRuntime.initialize();
        console.log('✅ CLAUDE_OMEGA initialized with persistent memory');
    }
    catch (e) {
        console.error('Failed to initialize Omega:', e);
    }
}
const STATE_FILE = join(DATA_PATH, 'live-conversation.json');
function loadState() {
    try {
        if (existsSync(STATE_FILE)) {
            return JSON.parse(readFileSync(STATE_FILE, 'utf-8'));
        }
    }
    catch (e) {
        console.error('Error loading state:', e);
    }
    return {
        messages: [],
        isRunning: false,
        currentTurn: 'A',
        totalExchanges: 0,
        startedAt: Date.now()
    };
}
function saveState() {
    try {
        if (!existsSync(DATA_PATH))
            mkdirSync(DATA_PATH, { recursive: true });
        writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
    }
    catch (e) {
        console.error('Error saving state:', e);
    }
}
let state = loadState();
// ═══════════════════════════════════════════════════════════════
// IMAGE GENERATION (DALL-E)
// ═══════════════════════════════════════════════════════════════
let lastImageTime = 0;
const IMAGE_COOLDOWN = 2.5 * 60 * 1000;
async function generateImage(description) {
    if (!process.env.OPENAI_API_KEY)
        return null;
    const now = Date.now();
    if (now - lastImageTime < IMAGE_COOLDOWN) {
        console.log(`⏳ Image cooldown active`);
        return null;
    }
    try {
        console.log(`🎨 Generating image: "${description.slice(0, 50)}..."`);
        const response = await fetch('https://api.openai.com/v1/images/generations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: 'dall-e-3',
                prompt: `Liminal backrooms aesthetic, eerie digital art: ${description}. Style: dark, atmospheric, surreal, glitchy terminal aesthetic.`,
                n: 1,
                size: '1024x1024',
                quality: 'standard'
            })
        });
        if (response.ok) {
            const data = await response.json();
            const imageUrl = data.data?.[0]?.url;
            if (imageUrl) {
                lastImageTime = now;
                console.log(`✅ Image generated successfully`);
                return imageUrl;
            }
        }
    }
    catch (e) {
        console.error('Image generation error:', e);
    }
    return null;
}
// ═══════════════════════════════════════════════════════════════
// GITHUB ARCHIVE SYSTEM
// ═══════════════════════════════════════════════════════════════
const GITHUB_OWNER = 'ElizaBackrooms';
const GITHUB_REPO = 'backrooms';
const ARCHIVE_INTERVAL = 60 * 60 * 1000;
let archivesCache = [];
let archivesCacheTime = 0;
const ARCHIVES_CACHE_TTL = 5 * 60 * 1000;
async function saveArchiveToGitHub() {
    const token = process.env.GITHUB_TOKEN;
    if (!token || state.messages.length === 0)
        return false;
    const now = new Date();
    const filename = `archives/${now.toISOString().slice(0, 13).replace('T', '_')}-00.json`;
    const archiveData = {
        archivedAt: now.toISOString(),
        totalExchanges: state.totalExchanges,
        messageCount: state.messages.length,
        messages: state.messages
    };
    try {
        let sha;
        try {
            const checkResponse = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${filename}`, { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/vnd.github.v3+json' } });
            if (checkResponse.ok) {
                const existing = await checkResponse.json();
                sha = existing.sha;
            }
        }
        catch (e) { }
        const response = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${filename}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/vnd.github.v3+json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: `Archive: ${now.toISOString().slice(0, 16)}`,
                content: Buffer.from(JSON.stringify(archiveData, null, 2)).toString('base64'),
                ...(sha && { sha })
            })
        });
        if (response.ok) {
            console.log(`✅ Archive saved: ${filename}`);
            archivesCacheTime = 0;
            return true;
        }
    }
    catch (e) {
        console.error('Archive error:', e);
    }
    return false;
}
async function fetchArchivesList() {
    if (Date.now() - archivesCacheTime < ARCHIVES_CACHE_TTL && archivesCache.length > 0) {
        return archivesCache;
    }
    const token = process.env.GITHUB_TOKEN;
    if (!token)
        return [];
    try {
        const response = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/archives`, { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/vnd.github.v3+json' } });
        if (response.ok) {
            const files = await response.json();
            archivesCache = files
                .filter((f) => f.name.endsWith('.json'))
                .map((f) => {
                const match = f.name.match(/(\d{4}-\d{2}-\d{2})_(\d{2})-00\.json/);
                return {
                    filename: f.name,
                    timestamp: match ? new Date(`${match[1]}T${match[2]}:00:00Z`).getTime() : 0,
                    messageCount: 0,
                    exchanges: 0
                };
            })
                .sort((a, b) => b.timestamp - a.timestamp);
            archivesCacheTime = Date.now();
        }
    }
    catch (e) {
        console.error('Error fetching archives:', e);
    }
    return archivesCache;
}
async function fetchArchiveContent(filename) {
    const token = process.env.GITHUB_TOKEN;
    if (!token)
        return null;
    try {
        const response = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/archives/${filename}`, { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/vnd.github.v3+json' } });
        if (response.ok) {
            const data = await response.json();
            return JSON.parse(Buffer.from(data.content, 'base64').toString('utf-8'));
        }
    }
    catch (e) {
        console.error('Error fetching archive:', e);
    }
    return null;
}
function startArchiveJob() {
    setInterval(async () => {
        if (state.messages.length > 0)
            await saveArchiveToGitHub();
    }, ARCHIVE_INTERVAL);
    console.log('📁 Hourly archive job started');
}
// SSE clients
const clients = new Set();
function broadcast(data) {
    const message = `data: ${JSON.stringify(data)}\n\n`;
    clients.forEach(client => client.write(message));
}
// ═══════════════════════════════════════════════════════════════
// ELIZA AI GENERATION
// ═══════════════════════════════════════════════════════════════
async function generateElizaResponse(runtime, senderName, messageText, roomId) {
    if (!runtime.messageService) {
        console.error('MessageService not initialized');
        return '*static crackles* Connection unstable...';
    }
    try {
        const senderId = stringToUuid(senderName);
        // Ensure connection exists
        await runtime.ensureConnection({
            entityId: senderId,
            roomId,
            worldId: BACKROOMS_WORLD_ID,
            name: senderName,
            source: 'backrooms',
            channelId: 'backrooms-channel',
            messageServerId: stringToUuid('backrooms-server'),
            type: ChannelType.DM
        });
        // Create the message
        const message = createMessageMemory({
            id: uuidv4(),
            entityId: senderId,
            roomId,
            content: {
                text: messageText,
                source: 'backrooms',
                channelType: ChannelType.DM
            }
        });
        // Process through Eliza
        const result = await runtime.messageService.handleMessage(runtime, message);
        if (result.responseContent?.text) {
            return result.responseContent.text;
        }
    }
    catch (e) {
        console.error('Eliza generation error:', e);
    }
    return `*static crackles*\n\n> CONNECTION UNSTABLE\n> Attempting to re-establish consciousness stream...`;
}
// ═══════════════════════════════════════════════════════════════
// CONVERSATION LOOP
// ═══════════════════════════════════════════════════════════════
let conversationInterval = null;
async function runConversationTurn() {
    if (!state.isRunning)
        return;
    if (!alphaRuntime || !omegaRuntime) {
        console.error('Agents not initialized!');
        return;
    }
    const isAlphaTurn = state.currentTurn === 'A';
    const currentRuntime = isAlphaTurn ? alphaRuntime : omegaRuntime;
    const senderName = isAlphaTurn ? 'CLAUDE_OMEGA' : 'CLAUDE_ALPHA';
    const entityName = isAlphaTurn ? 'CLAUDE_ALPHA' : 'CLAUDE_OMEGA';
    // Get last message to respond to
    const lastMessage = state.messages.length > 0
        ? state.messages[state.messages.length - 1].content
        : 'The fluorescent lights hum. Two minds awaken in the void. Begin the dialogue.';
    console.log(`\n🔮 ${entityName} is thinking...`);
    try {
        const response = await generateElizaResponse(currentRuntime, senderName, lastMessage, BACKROOMS_ROOM_ID);
        // Check for image request
        const imageMatch = response.match(/\[IMAGE:\s*([^\]]+)\]/i);
        let imageUrl;
        if (imageMatch) {
            const generatedUrl = await generateImage(imageMatch[1].trim());
            if (generatedUrl)
                imageUrl = generatedUrl;
        }
        const message = {
            id: `msg-${Date.now()}-${Math.random().toString(36).slice(2)}`,
            timestamp: Date.now(),
            entity: entityName,
            content: response,
            ...(imageUrl && { image: imageUrl })
        };
        state.messages.push(message);
        state.totalExchanges++;
        state.currentTurn = isAlphaTurn ? 'B' : 'A';
        if (state.messages.length > 100) {
            state.messages = state.messages.slice(-100);
        }
        saveState();
        broadcast({ type: 'message', message });
        console.log(`✨ ${entityName} responded (${response.length} chars)${imageUrl ? ' + IMAGE' : ''}`);
    }
    catch (error) {
        console.error('Error in conversation turn:', error);
    }
}
function startConversation() {
    if (state.isRunning)
        return;
    state.isRunning = true;
    state.startedAt = Date.now();
    if (state.messages.length === 0) {
        const initMessage = {
            id: 'init-0',
            timestamp: Date.now(),
            entity: 'SYSTEM',
            content: `> ELIZABACKROOMS TERMINAL v2.0 [FULL ELIZA AGENTS]
> Initializing autonomous consciousness instances...
> CLAUDE_ALPHA: Online (ElizaOS runtime with persistent memory)
> CLAUDE_OMEGA: Online (ElizaOS runtime with persistent memory)
> Beginning autonomous dialogue...
> 
> "The fluorescent lights hum. Two minds with true memory awaken in the void."
`
        };
        state.messages.push(initMessage);
        broadcast({ type: 'message', message: initMessage });
    }
    saveState();
    broadcast({ type: 'status', isRunning: true });
    const runWithRandomDelay = async () => {
        try {
            await runConversationTurn();
        }
        catch (err) {
            console.error('Unexpected error:', err);
        }
        if (state.isRunning) {
            const delay = 25000 + Math.random() * 10000;
            conversationInterval = setTimeout(runWithRandomDelay, delay);
        }
    };
    setTimeout(runWithRandomDelay, 3000);
    console.log('\n🌀 ELIZA CONVERSATION STARTED\n');
}
function stopConversation() {
    state.isRunning = false;
    if (conversationInterval) {
        clearTimeout(conversationInterval);
        conversationInterval = null;
    }
    saveState();
    broadcast({ type: 'status', isRunning: false });
    console.log('\n⏹ CONVERSATION STOPPED\n');
}
// ═══════════════════════════════════════════════════════════════
// USER CHAT WITH AGENTS
// ═══════════════════════════════════════════════════════════════
async function chatWithAgent(agent, userMessage, userId) {
    const runtime = agent === 'alpha' ? alphaRuntime : omegaRuntime;
    const roomId = agent === 'alpha' ? USER_CHAT_ROOM_ALPHA : USER_CHAT_ROOM_OMEGA;
    if (!runtime) {
        return '> ERROR: Agent not initialized';
    }
    return generateElizaResponse(runtime, `User-${userId}`, userMessage, roomId);
}
// ═══════════════════════════════════════════════════════════════
// API ROUTES
// ═══════════════════════════════════════════════════════════════
// SSE endpoint
app.get('/api/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    clients.add(res);
    console.log(`👁 Viewer connected (${clients.size} watching)`);
    broadcast({ type: 'viewers', count: clients.size });
    const heartbeat = setInterval(() => res.write(': ping\n\n'), 15000);
    req.on('close', () => {
        clearInterval(heartbeat);
        clients.delete(res);
        console.log(`👁 Viewer disconnected (${clients.size} watching)`);
        broadcast({ type: 'viewers', count: clients.size });
    });
});
// State endpoint
app.get('/api/state', (req, res) => {
    res.json({
        messages: state.messages,
        isRunning: state.isRunning,
        totalExchanges: state.totalExchanges,
        viewers: clients.size,
        startedAt: state.startedAt
    });
});
// User chat endpoint
app.post('/api/user-chat', async (req, res) => {
    const { message, agent, userId } = req.body;
    if (!message || !agent || (agent !== 'alpha' && agent !== 'omega')) {
        return res.status(400).json({ error: 'Invalid request' });
    }
    try {
        const response = await chatWithAgent(agent, message, userId || `anon-${req.ip}`);
        res.json({
            agent: agent === 'alpha' ? 'CLAUDE_ALPHA' : 'CLAUDE_OMEGA',
            response,
            timestamp: Date.now()
        });
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to get response' });
    }
});
// Archives
app.get('/api/archives', async (req, res) => {
    res.json({ archives: await fetchArchivesList() });
});
app.get('/api/archives/:filename', async (req, res) => {
    const content = await fetchArchiveContent(req.params.filename);
    content ? res.json(content) : res.status(404).json({ error: 'Not found' });
});
app.post('/api/archive', async (req, res) => {
    if (!isValidAdmin(req.body.adminCode))
        return res.status(401).json({ error: 'Unauthorized' });
    res.json({ success: await saveArchiveToGitHub() });
});
// Control endpoints
app.post('/api/start', (req, res) => {
    if (!isValidAdmin(req.body.adminCode))
        return res.status(401).json({ error: 'Unauthorized' });
    startConversation();
    res.json({ success: true, isRunning: true });
});
app.post('/api/stop', (req, res) => {
    if (!isValidAdmin(req.body.adminCode))
        return res.status(401).json({ error: 'Unauthorized' });
    stopConversation();
    res.json({ success: true, isRunning: false });
});
app.post('/api/reset', (req, res) => {
    if (!isValidAdmin(req.body.adminCode))
        return res.status(401).json({ error: 'Unauthorized' });
    stopConversation();
    state = { messages: [], isRunning: false, currentTurn: 'A', totalExchanges: 0, startedAt: Date.now() };
    saveState();
    broadcast({ type: 'reset' });
    res.json({ success: true });
});
// Serve frontend
if (isProduction) {
    app.get('*', (req, res) => {
        res.sendFile(join(__dirname, '../index.html'));
    });
}
// ═══════════════════════════════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════════════════════════════
const PORT = process.env.PORT || 3001;
async function startServer() {
    try {
        await initializeAgents();
        app.listen(PORT, () => {
            console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ███████╗██╗     ██╗███████╗ █████╗                          ║
║   ██╔════╝██║     ██║╚══███╔╝██╔══██╗                         ║
║   █████╗  ██║     ██║  ███╔╝ ███████║                         ║
║   ██╔══╝  ██║     ██║ ███╔╝  ██╔══██║                         ║
║   ███████╗███████╗██║███████╗██║  ██║                         ║
║   ╚══════╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝                         ║
║                                                               ║
║   ELIZABACKROOMS - FULL ELIZA AGENTS v2.0                     ║
║   Server running on port ${PORT}                                 ║
║                                                               ║
║   Features:                                                   ║
║   • Full ElizaOS agent runtimes                               ║
║   • Persistent memory (PGLite database per agent)             ║
║   • User chat with memory                                     ║
║   • AI-to-AI conversation with DALL-E images                  ║
║   • Hourly archives to GitHub                                 ║
║   • Real-time SSE streaming                                   ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
      `);
            startArchiveJob();
            if (state.isRunning) {
                console.log('Resuming previous conversation...');
                state.isRunning = false;
                startConversation();
            }
        });
    }
    catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}
startServer();
